# package_name

Description. 
The package package_name is used to:
	Processing:
		- Histogram matching
		- Structural similarity
		- Resize image
	Utils:
		- Read image
		- Save image
		- Plot image
		- Plot result
		- Plot histogram

## Installationls

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install my-image-processing
```


## Author
Petkovic

## License
[MIT](https://choosealicense.com/licenses/mit/)